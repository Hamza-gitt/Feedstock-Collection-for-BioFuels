import pyomo.environ as pyo

# Define locations
suppliers = ['Karnal', 'Kurukshetra', 'Ambala', 'Yamunanagar', 'Hisar']
storage_facilities = ['Jind', 'Kaithal', 'Sonipat']

# Define biomass availability at each supplier (in tons)
biomass_availability = {
    'Karnal': 602,
    'Kurukshetra': 935,
    'Ambala': 1360,
    'Yamunanagar': 770,
    'Hisar': 606
}

# Define storage capacities at each storage facility (in tons)
storage_capacities = {
    'Jind': 2095,
    'Kaithal': 4772,
    'Sonipat': 4092
}

# Define transportation costs (per ton)
transportation_costs = {
    ('Karnal', 'Jind'): 110,
    ('Karnal', 'Kaithal'): 130,
    ('Karnal', 'Sonipat'): 140,
    ('Kurukshetra', 'Jind'): 90,
    ('Kurukshetra', 'Kaithal'): 110,
    ('Kurukshetra', 'Sonipat'): 160,
    ('Ambala', 'Jind'): 140,
    ('Ambala', 'Kaithal'): 160,
    ('Ambala', 'Sonipat'): 200,
    ('Yamunanagar', 'Jind'): 180,
    ('Yamunanagar', 'Kaithal'): 200,
    ('Yamunanagar', 'Sonipat'): 240,
    ('Hisar', 'Jind'): 80,
    ('Hisar', 'Kaithal'): 100,
    ('Hisar', 'Sonipat'): 180
}

# Create the Pyomo model
model = pyo.ConcreteModel()

# Sets
model.suppliers = pyo.Set(initialize=suppliers)
model.storage_facilities = pyo.Set(initialize=storage_facilities)

# Parameters
model.biomass_availability = pyo.Param(model.suppliers, initialize=biomass_availability)
model.storage_capacities = pyo.Param(model.storage_facilities, initialize=storage_capacities)
model.transportation_costs = pyo.Param(model.suppliers * model.storage_facilities, initialize=transportation_costs, within=pyo.NonNegativeReals)

# Variables
model.x = pyo.Var(model.suppliers, model.storage_facilities, within=pyo.NonNegativeReals)
model.y = pyo.Var(model.storage_facilities, within=pyo.Binary)

# Objective function: Minimize total transportation cost plus penalty for not using storage facilities
def objective_rule(model):
    transportation_cost = sum(model.transportation_costs[s, t] * model.x[s, t] for s in model.suppliers for t in model.storage_facilities)
    storage_penalty = sum((1 - model.y[t]) * 100000 for t in model.storage_facilities)
    return transportation_cost + storage_penalty

model.objective = pyo.Objective(rule=objective_rule, sense=pyo.minimize)

# Constraints

# Ensure biomass availability constraints are met
def biomass_availability_rule(model, s):
    return sum(model.x[s, t] for t in model.storage_facilities) <= model.biomass_availability[s]

model.biomass_availability_constraint = pyo.Constraint(model.suppliers, rule=biomass_availability_rule)

# Ensure storage capacities are not exceeded
def storage_capacity_rule(model, t):
    return sum(model.x[s, t] for s in model.suppliers) <= model.storage_capacities[t] * model.y[t]

model.storage_capacity_constraint = pyo.Constraint(model.storage_facilities, rule=storage_capacity_rule)

# Ensure storage facility is used if it has biomass
def storage_usage_rule(model, t):
    return sum(model.x[s, t] for s in model.suppliers) >= 0.1 * model.y[t]

model.storage_usage_constraint = pyo.Constraint(model.storage_facilities, rule=storage_usage_rule)

# Minimum transportation requirement from each supplier
def minimum_transportation_rule(model, s):
    return sum(model.x[s, t] for t in model.storage_facilities) >= 0.5 * model.biomass_availability[s]

model.minimum_transportation_constraint = pyo.Constraint(model.suppliers, rule=minimum_transportation_rule)

# Solve the model
solver = pyo.SolverFactory('glpk')
result = solver.solve(model, tee=True)

# Print the results
print("Status:", result.solver.status)
print("Termination Condition:", result.solver.termination_condition)

print("\nOptimal Transportation Plan:")
for s in model.suppliers:
    for t in model.storage_facilities:
        transported_amount = pyo.value(model.x[s, t])
        if transported_amount > 0:
            print(f"Transport {transported_amount:.2f} tons from {s} to {t}")

print("\nStorage Facilities Used:")
for t in model.storage_facilities:
    storage_used = pyo.value(model.y[t])
    if storage_used >= 0.99:
        print(f"Storage facility {t} is used")
    else:
        print(f"Storage facility {t} is not used")

print("\nDetailed Transport Amounts:")
for s in model.suppliers:
    for t in model.storage_facilities:
        print(f"{s} -> {t}: {pyo.value(model.x[s, t])}")

print("\nDetailed Storage Facility Usage:")
for t in model.storage_facilities:
    print(f"{t}: {pyo.value(model.y[t])}")
