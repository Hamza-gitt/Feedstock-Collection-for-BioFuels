from faker import Faker
import random
import pandas as pd

# Initialize Faker library
fake = Faker('en_IN')  # For Indian context

# Define function to generate synthetic data for a location
def generate_synthetic_data(location):
    data = []
    for _ in range(100):  # Generate data for 100 time periods (e.g., months)
        date = fake.date_this_decade()  # Generate a random date within the current decade
        weather_pattern = random.choice(['Sunny', 'Rainy', 'Cloudy'])  # Random weather pattern
        temperature = random.uniform(20, 40)  # Random temperature in Celsius
        rainfall = random.uniform(0, 100)  # Random rainfall in mm
        agricultural_cycle = random.choice(['Planting', 'Growing', 'Harvesting'])  # Random agricultural cycle phase
        industrial_activity = random.choice(['Low', 'Medium', 'High'])  # Random industrial activity level
        
        # Generate synthetic data for wasteage availability, demand, prices, etc.
        wasteage_availability = random.uniform(1000, 5000)  # Random wasteage availability in tonnes
        wasteage_demand = random.uniform(800, 4500)  # Random wasteage demand in tonnes
        wasteage_price = random.uniform(1000, 3000)  # Random wasteage price in INR per tonne
        
        # Append data to list
        data.append([location, date, weather_pattern, temperature, rainfall, agricultural_cycle, industrial_activity,
                     wasteage_availability, wasteage_demand, wasteage_price])
    
    return data

# Define list of locations in Haryana
locations = ['Ambala', 'Faridabad', 'Gurgaon', 'Hisar', 'Karnal', 'Kurukshetra', 'Panipat', 'Rohtak', 'Sonipat', 'Yamunanagar']

# Generate synthetic data for each location
all_data = []
for location in locations:
    all_data.extend(generate_synthetic_data(location))

# Create DataFrame from generated data
df = pd.DataFrame(all_data, columns=['Location', 'Date', 'Weather Pattern', 'Temperature (°C)', 'Rainfall (mm)',
                                     'Agricultural Cycle', 'Industrial Activity', 'Wasteage Availability (tonnes)',
                                     'Wasteage Demand (tonnes)', 'Wasteage Price (INR/tonne)'])

# Display sample of generated synthetic data
print(df.head())

# Save synthetic data to CSV file
df.to_csv('synthetic_wasteage_data.csv', index=False)
