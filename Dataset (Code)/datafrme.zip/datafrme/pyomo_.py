from pyomo.environ import *
import pandas as pd

# Load datasets
farm_data = pd.read_csv('farm_data.csv')
collector_data = pd.read_csv('collector_data.csv')
company_data = pd.read_csv('company_data.csv')
environment_data = pd.read_csv('environment_data.csv')
economic_data = pd.read_csv('economic_data.csv')


# Initialize the model
model = ConcreteModel()

# Sets
model.Farms = RangeSet(1, len(farm_data))
model.Collectors = RangeSet(1, len(collector_data))
model.Companies = RangeSet(1, len(company_data))
model.Days = RangeSet(1, len(economic_data))

# Parameters
farm_yield = farm_data.set_index('Farm_ID')['Biomass_yield_tons'].to_dict()
selling_price = farm_data.set_index('Farm_ID')['Selling_price_USD_per_ton'].to_dict()
transport_cost = collector_data.set_index('Collector_ID')['Transportation_cost_USD'].to_dict()
storage_cost = collector_data.set_index('Collector_ID')['Storage_cost_USD'].to_dict()
handling_cost = collector_data.set_index('Collector_ID')['Handling_cost_USD_per_ton'].to_dict()
purchase_cost = company_data.set_index('Company_ID')['Biomass_purchase_cost_USD_per_ton'].to_dict()
operational_cost = company_data.set_index('Company_ID')['Operational_costs_USD_per_day'].to_dict()
conversion_efficiency = company_data.set_index('Company_ID')['Conversion_efficiency_percent'].to_dict()
market_demand = economic_data.set_index('Day')['Market_demand_liters_per_day'].to_dict()
selling_price_biofuel = economic_data.set_index('Day')['Biofuel_selling_price_USD_per_liter'].to_dict()
subsidies = economic_data.set_index('Day')['Government_subsidies_USD_per_liter'].to_dict()

# Decision Variables
model.Production = Var(model.Farms, domain=NonNegativeReals)
model.Transport = Var(model.Collectors, domain=NonNegativeReals)
model.Storage = Var(model.Collectors, domain=NonNegativeReals)
model.Processing = Var(model.Companies, domain=NonNegativeReals)
model.BiofuelProduced = Var(model.Companies, model.Days, domain=NonNegativeReals)
model.BiofuelSold = Var(model.Companies, model.Days, domain=NonNegativeReals)

# Objective Function: Maximize profit
def objective_rule(model):
    revenue = sum(model.BiofuelSold[c, d] * (selling_price_biofuel[d] + subsidies[d]) for c in model.Companies for d in model.Days)
    production_costs = sum(model.Production[f] * selling_price[f] for f in model.Farms)
    transport_costs = sum(model.Transport[t] * transport_cost[t] for t in model.Collectors)
    storage_costs = sum(model.Storage[s] * storage_cost[s] for s in model.Collectors)
    operational_costs = sum(model.Processing[c] * operational_cost[c] for c in model.Companies)
    return revenue - (production_costs + transport_costs + storage_costs + operational_costs)

model.Objective = Objective(rule=objective_rule, sense=maximize)

# Constraints

# Supply constraint: Biofuel produced should meet market demand
def supply_constraint_rule(model, d):
    return sum(model.BiofuelProduced[c, d] for c in model.Companies) >= market_demand[d]

model.SupplyConstraint = Constraint(model.Days, rule=supply_constraint_rule)

# Production constraint: Production should not exceed farm yield
def production_constraint_rule(model, f):
    return model.Production[f] <= farm_yield[f]

model.ProductionConstraint = Constraint(model.Farms, rule=production_constraint_rule)

# Transportation constraint: Transport should not exceed collection capacity
def transport_constraint_rule(model, t):
    return model.Transport[t] <= sum(model.Production[f] for f in model.Farms)

model.TransportConstraint = Constraint(model.Collectors, rule=transport_constraint_rule)

# Storage constraint: Storage should not exceed capacity
def storage_constraint_rule(model, s):
    return model.Storage[s] <= collector_data.loc[s - 1, 'Storage_capacity_tons']

model.StorageConstraint = Constraint(model.Collectors, rule=storage_constraint_rule)

# Processing constraint: Processing should not exceed plant capacity
def processing_constraint_rule(model, c):
    return sum(model.BiofuelProduced[c, d] for d in model.Days) <= company_data.loc[c - 1, 'Plant_capacity_tons_per_day'] * len(model.Days)

model.ProcessingConstraint = Constraint(model.Companies, rule=processing_constraint_rule)

# Link biofuel produced to processing
def biofuel_produced_rule(model, c, d):
    return model.BiofuelProduced[c, d] <= model.Processing[c] * conversion_efficiency[c] / 100

model.BiofuelProducedConstraint = Constraint(model.Companies, model.Days, rule=biofuel_produced_rule)

# Biofuel sold should not exceed biofuel produced
def biofuel_sold_rule(model, c, d):
    return model.BiofuelSold[c, d] <= model.BiofuelProduced[c, d]

model.BiofuelSoldConstraint = Constraint(model.Companies, model.Days, rule=biofuel_sold_rule)

# Solve the model
solver = SolverFactory('glpk')
results = solver.solve(model, tee=True)

# Display results
print("Objective value: ", model.Objective())
for f in model.Farms:
    print(f"Farm {f} production: {model.Production[f].value}")
for t in model.Collectors:
    print(f"Collector {t} transport: {model.Transport[t].value}")
for s in model.Collectors:
    print(f"Collector {s} storage: {model.Storage[s].value}")
for c in model.Companies:
    print(f"Company {c} processing: {model.Processing[c].value}")
for c in model.Companies:
    for d in model.Days:
        print(f"Company {c} biofuel produced on day {d}: {model.BiofuelProduced[c, d].value}")
        print(f"Company {c} biofuel sold on day {d}: {model.BiofuelSold[c, d].value}")
