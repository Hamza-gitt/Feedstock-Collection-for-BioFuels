import numpy as np
import pandas as pd

# Set random seed for reproducibility
np.random.seed(42)

# Define number of entries
num_farms = 100
num_collectors = 10
num_companies = 5
num_days = 30

# Generate farmer data
farm_data = pd.DataFrame({
    'Farm_ID': range(1, num_farms + 1),
    'Biomass_yield_tons': np.random.uniform(50, 200, num_farms),
    'Production_costs_USD': np.random.uniform(1000, 5000, num_farms),
    'Selling_price_USD_per_ton': np.random.uniform(50, 150, num_farms),
    'Soil_quality': np.random.randint(1, 11, num_farms),
    'Water_availability_liters': np.random.uniform(10000, 50000, num_farms),
    'Fertilizer_usage_kg': np.random.uniform(200, 1000, num_farms),
    'Labor_cost_USD': np.random.uniform(500, 2000, num_farms)
})

# Generate collector data
collector_data = pd.DataFrame({
    'Collector_ID': range(1, num_collectors + 1),
    'Collection_point_ID': np.random.randint(1, num_farms + 1, num_collectors),
    'Distance_to_farms_km': np.random.uniform(10, 100, num_collectors),
    'Transportation_cost_USD': np.random.uniform(100, 500, num_collectors),
    'Storage_capacity_tons': np.random.uniform(500, 2000, num_collectors),
    'Storage_cost_USD': np.random.uniform(1000, 5000, num_collectors),
    'Handling_cost_USD_per_ton': np.random.uniform(10, 50, num_collectors)
})

# Generate company data
company_data = pd.DataFrame({
    'Company_ID': range(1, num_companies + 1),
    'Processing_plant_ID': range(1, num_companies + 1),
    'Plant_capacity_tons_per_day': np.random.uniform(100, 500, num_companies),
    'Biomass_purchase_cost_USD_per_ton': np.random.uniform(50, 150, num_companies),
    'Operational_costs_USD_per_day': np.random.uniform(5000, 20000, num_companies),
    'Conversion_efficiency_percent': np.random.uniform(70, 90, num_companies),
    'Energy_usage_kWh_per_day': np.random.uniform(1000, 5000, num_companies),
    'Labor_cost_USD_per_day': np.random.uniform(1000, 5000, num_companies),
    'Maintenance_cost_USD_per_day': np.random.uniform(500, 2000, num_companies),
    'Biofuel_yield_liters_per_ton': np.random.uniform(200, 500, num_companies)
})

# Generate environmental impact data
environment_data = pd.DataFrame({
    'Company_ID': range(1, num_companies + 1),
    'Emission_levels_CO2e_per_ton': np.random.uniform(0.1, 1.0, num_companies),
    'Water_usage_liters_per_ton': np.random.uniform(1000, 5000, num_companies),
    'Land_usage_hectares': np.random.uniform(1, 10, num_companies),
    'Waste_produced_tons': np.random.uniform(10, 50, num_companies)
})

# Generate economic factor data
economic_data = pd.DataFrame({
    'Day': range(1, num_days + 1),
    'Market_demand_liters_per_day': np.random.uniform(1000, 10000, num_days),
    'Biofuel_selling_price_USD_per_liter': np.random.uniform(1, 3, num_days),
    'Government_subsidies_USD_per_liter': np.random.uniform(0.1, 0.5, num_days),
    'Employment_jobs': np.random.randint(50, 200, num_days),
    'Local_income_levels_USD_per_year': np.random.uniform(2000, 10000, num_days)
})

# Save datasets to CSV files
farm_data.to_csv('farm_data.csv', index=False)
collector_data.to_csv('collector_data.csv', index=False)
company_data.to_csv('company_data.csv', index=False)
environment_data.to_csv('environment_data.csv', index=False)
economic_data.to_csv('economic_data.csv', index=False)

print("Synthetic datasets generated and saved to CSV files.")
