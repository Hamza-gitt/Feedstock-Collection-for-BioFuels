import pandas as pd
import numpy as np
from faker import Faker

fake = Faker()

# Generate synthetic data for farmers
num_farmers = 100
farmers_data = {
    'Farmer_ID': range(1, num_farmers + 1),
    'Location': [fake.city() for _ in range(num_farmers)],
    'Land_Area_Acres': np.random.randint(10, 100, num_farmers),
    'Crop_Type': [np.random.choice(['Wheat', 'Corn', 'Sugarcane']) for _ in range(num_farmers)],
    'Crop_Yield_Tons_Acre': np.random.uniform(1, 5, num_farmers),
    'Harvest_Time': [fake.date_between(start_date='-6m', end_date='today') for _ in range(num_farmers)],
    'Water_Availability': [np.random.choice(['High', 'Medium', 'Low']) for _ in range(num_farmers)],
    'Fertilizer_Type': [np.random.choice(['Organic', 'Inorganic']) for _ in range(num_farmers)],
    'Fertilizer_Usage_Kg_Acre': np.random.uniform(10, 50, num_farmers),
    'Pesticide_Usage_Kg_Acre': np.random.uniform(5, 20, num_farmers),
    'Production_Cost_Per_Acre': np.random.uniform(500, 2000, num_farmers),
    'Selling_Price_Per_Ton': np.random.uniform(200, 500, num_farmers)
}

farmers_df = pd.DataFrame(farmers_data)
print(farmers_df.head())
