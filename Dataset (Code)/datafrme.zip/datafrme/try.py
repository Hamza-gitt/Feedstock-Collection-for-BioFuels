import random
import pandas as pd

# Data preparation for 30 villages
villages = []
village_names = [f"Village {chr(65 + i)}" for i in range(30)]
district = "Karnal"
state = "Haryana"
base_latitude = 29.6850
base_longitude = 76.9905

for i in range(30):
    village_name = village_names[i]
    latitude = base_latitude + random.uniform(-0.05, 0.05)
    longitude = base_longitude + random.uniform(-0.05, 0.05)
    total_cultivable_area = random.randint(800, 1500)
    rice_cultivation_area = total_cultivable_area * random.uniform(0.5, 0.7)
    wheat_cultivation_area = total_cultivable_area * random.uniform(0.3, 0.5)
    avg_yield_per_ha_rice = random.uniform(1.5, 10)
    avg_yield_per_ha_wheat = random.uniform(1, 5)
    total_harvested_waste_rice = rice_cultivation_area * avg_yield_per_ha_rice * 0.5
    total_harvested_waste_wheat = wheat_cultivation_area * avg_yield_per_ha_wheat * 0.5
    total_harvested_waste = total_harvested_waste_rice + total_harvested_waste_wheat

    village = {
        "Village Name": village_name,
        "Latitude": latitude,
        "Longitude": longitude,
        "Total Cultivable Area (ha)": total_cultivable_area,
        "Rice Cultivation Area (ha)": rice_cultivation_area,
        "Wheat Cultivation Area (ha)": wheat_cultivation_area,
        "Avg Yield per ha (Rice)": avg_yield_per_ha_rice,
        "Avg Yield per ha (Wheat)": avg_yield_per_ha_wheat,
        "Total Harvested Waste (Rice) (tons)": total_harvested_waste_rice,
        "Total Harvested Waste (Wheat) (tons)": total_harvested_waste_wheat,
        "Total Harvested Waste (tons)": total_harvested_waste
    }
    
    villages.append(village)

village_df = pd.DataFrame(villages)
village_df.to_csv("villages_data.csv", index=False)
