import pandas as pd
import numpy as np

# Define locations
suppliers = ['Karnal', 'Kurukshetra', 'Ambala', 'Yamunanagar', 'Hisar']
storage_facilities = ['Jind', 'Kaithal', 'Sonipat']
ethanol_plant = 'Panipat'

# Generate synthetic biomass availability data (in tons)
np.random.seed(42)  # For reproducibility
biomass_availability = np.random.randint(500, 1500, size=len(suppliers))

biomass_data = pd.DataFrame({
    'Supplier': suppliers,
    'Biomass_Availability': biomass_availability
})

print(biomass_data)
# Distance matrix (in km) between locations
distance_matrix = {
    'Karnal': {'Jind': 55, 'Kaithal': 65, 'Sonipat': 70, 'Panipat': 35},
    'Kurukshetra': {'Jind': 45, 'Kaithal': 55, 'Sonipat': 80, 'Panipat': 50},
    'Ambala': {'Jind': 70, 'Kaithal': 80, 'Sonipat': 100, 'Panipat': 85},
    'Yamunanagar': {'Jind': 90, 'Kaithal': 100, 'Sonipat': 120, 'Panipat': 110},
    'Hisar': {'Jind': 40, 'Kaithal': 50, 'Sonipat': 90, 'Panipat': 75}
}

# Generate synthetic transportation costs (per ton per km)
cost_per_km = 2  # Cost per ton per km
transportation_costs = {}

for supplier, distances in distance_matrix.items():
    transportation_costs[supplier] = {location: distance * cost_per_km for location, distance in distances.items()}

transportation_costs_df = pd.DataFrame(transportation_costs).T

print(transportation_costs_df)
# Generate synthetic storage capacities (in tons)
storage_capacities = np.random.randint(1000, 5000, size=len(storage_facilities))

storage_data = pd.DataFrame({
    'Storage_Facility': storage_facilities,
    'Storage_Capacity': storage_capacities
})

print(storage_data)
# Generate synthetic processing capacity (in tons per day)
processing_capacity = 2000  # Assume the plant processes 2000 tons per day

processing_data = pd.DataFrame({
    'Ethanol_Plant': [ethanol_plant],
    'Processing_Capacity': [processing_capacity]
})

print(processing_data)
# Combine data into a single DataFrame
combined_data = {
    'Suppliers': suppliers,
    'Biomass_Availability': biomass_availability,
    'Storage_Facilities': storage_facilities,
    'Storage_Capacities': storage_capacities,
    'Transportation_Costs': transportation_costs,
    'Processing_Capacity': processing_capacity
}

# Save to CSV
biomass_data.to_csv('biomass_data.csv', index=False)
transportation_costs_df.to_csv('transportation_costs.csv')
storage_data.to_csv('storage_data.csv', index=False)
processing_data.to_csv('processing_data.csv', index=False)

print("Synthetic data created and saved to CSV files.")
