import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pymoo.core.problem import Problem
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.optimize import minimize

# Define the problem class
class WasteCollectionProblem(Problem):
    def __init__(self, villages):
        super().__init__(n_var=len(villages), 
                         n_obj=2, 
                         n_constr=0, 
                         xl=np.zeros(len(villages)), 
                         xu=[v['Total Harvested Waste (tons)'] for v in villages])
        self.villages = villages
        self.processing_plant_location = (29.39, 76.97)  # Coordinates of the processing plant in Panipat

    def _evaluate(self, X, out, *args, **kwargs):
        total_waste = np.sum(X, axis=1)  # Sum along the rows to get total waste for each solution
        total_distance_cost = np.sum([
            X[:, i] * np.sqrt((village['Latitude'] - self.processing_plant_location[0])**2 + (village['Longitude'] - self.processing_plant_location[1])**2)
            for i, village in enumerate(self.villages)
        ], axis=0)  # Sum along the columns to get total distance cost for each solution
        out["F"] = np.column_stack((-total_waste, total_distance_cost))  # Stack objectives horizontally

# Load villages data
file_path = 'villages_data.csv'
villages_data = pd.read_csv(file_path)

# Prepare villages list
villages = villages_data.to_dict('records')

# Create the problem instance
problem = WasteCollectionProblem(villages)

# Define the algorithm
algorithm = NSGA2(pop_size=100)

# Perform the optimization
res = minimize(problem,
               algorithm,
               ('n_gen', 200),
               seed=1,
               verbose=True)

# Extract and print results
best_solutions = res.X
best_objectives = res.F

print("Best solutions:")
print(best_solutions)
print("Best objectives:")
print(best_objectives)

# Convert objectives for plotting
total_collected_waste = -best_objectives[:, 0]  # Revert the negative sign to get actual waste values
total_delivery_cost = best_objectives[:, 1]

# Plot the Pareto front
plt.figure(figsize=(8, 6))
plt.scatter(total_collected_waste, total_delivery_cost, c='b', marker='o', label='Solutions')

# Highlight the optimal solutions with the highest total collected waste
optimal_indices = np.where(total_collected_waste == np.max(total_collected_waste))[0]
plt.scatter(total_collected_waste[optimal_indices], total_delivery_cost[optimal_indices], c='r', marker='o', label='Optimal solutions')

plt.title('Pareto Front with Optimal Solutions Highlighted')
plt.xlabel('Total Collected Waste (tons)')
plt.ylabel('Total Delivery Cost')
plt.legend()
plt.grid(True)
plt.show()
