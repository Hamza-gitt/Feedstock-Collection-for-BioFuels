import pandas as pd
from pyomo.environ import *

# Load datasets
farm_data = pd.read_csv('farm_data.csv')
collector_data = pd.read_csv('collector_data.csv')
company_data = pd.read_csv('company_data.csv')
environment_data = pd.read_csv('environment_data.csv')
economic_data = pd.read_csv('economic_data.csv')

print("Farm Data:")
print(farm_data)
print("\nCollector Data:")
print(collector_data)
print("\nCompany Data:")
print(company_data)
print("\nEnvironment Data:")
print(environment_data)
print("\nEconomic Data:")
print(economic_data)
